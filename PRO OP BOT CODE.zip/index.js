const http = require("http");
const settings = require("./settings.json");
const express = require("express");
const app = express();
const server = http.createServer(app);
app.set('view engine', 'ejs');
app.use(express.static("public"));


app.get("/", (req, res) => {
    res.render('index', { bot: settings.website })
})

app.get("/commands", (req, res) => {
  res.render("commands", {bot: settings.website, commands: settings.commands })
})

const listener = server.listen(8000, function() {
    console.log("Your app is listening on port " + listener.address().port);
})


const { pro_op } = require('./config.json');
const { prefix } = require('./config.json');
const {base_lang} = require('./config.json')
const { premium_users } = require('./config.json');
const { premium_servers } = require('./config.json');
const { website } = require('./config.json');
const { default_prefix } = require('./config.json');
const { ownerID } = require('./config.json');
const { config } = require('dotenv');
let Translator = require("./translator.js");
const fetch = require('node-fetch');
const Eris = require('eris');
const modules = require('modules');
const util = require("util")
const mongoose = require('mongoose');
const ejs = require("ejs")
const eco = require('quick.eco');
const querystring = require('querystring');
const db = require('quick.db');
const moment = require('moment');
const { CanvasSenpai } = require('canvas-senpai');
const Levels = require('discord-xp');
const mconfig = require('./main.json');
const chalk = require("chalk")
const canva = new CanvasSenpai();
const discord = require('discord.js');
const { default: { stream } } = require("got");
const { execSync } = require("child_process");

const Enmap = require("enmap")
const client = new discord.Client({
	disableEveryone: true
});
require('discord-buttons')(client)
const url = "https://ci.fredboat.com/repository/download/Lavalink_Build/.lastSuccessful/Lavalink.jar?guest=1&branch=refs/heads/dev";

 
client.on("debug", console.log)
const yts = require('yt-search');
client.eco = new eco.Manager(); // quick.eco
client.queue = new Map();
client.vote = new Map();
client.afk = new Map();
const { ready } = require('./handlers/ready.js');

client.commands = new discord.Collection();
client.aliases = new discord.Collection();

['command', 'events'].forEach(handler => {
	require(`./handlers/${handler}`)(client);
});
client.on('message', async message => {
	const prefixMention = new RegExp(`^<@!?${client.user.id}>( |)$`);
	if (message.content.match(prefixMention)) {
		return message.reply(`My prefix is \`${default_prefix}\``);
	}
	client.on('message', async message => {
		if (message.author.bot === true) return;

		const randomXp = Math.floor(Math.random() * 46) + 1;
		const hasLeveledUp = await Levels.appendXp(
			message.author.id,
			message.guild.id,
			randomXp
		);

		if (hasLeveledUp) {
			const User = await Levels.fetch(message.author.id, message.guild.id);

			const LevelUp = new Discord.MessageEmbed()
				.setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
				.setTitle(`${message.author.username} Leveled Up.`)
				.setDescription(
					`${message.author} You have leveled up to **${User.level}**`
				)
				.setColor('#c98aff')
				.setTimestamp();
			message.channel.send(LevelUp);

			const Level_Roles_Storage = fs.readFileSync('Storages/Level-Roles.json');
			const Level_Roles = JSON.parse(Level_Roles_Storage.toString());

			const Guild_Check = Level_Roles.find(guild => {
				return guild.guildID === `${message.guild.id}`;
			});
			if (!Guild_Check) return;

			const Guild_Roles = Level_Roles.filter(guild => {
				return guild.guildID === `${message.guild.id}`;
			});
			//For Loop Works for Checking
			for (let i = 0; i < Guild_Roles.length; i++) {
				const User = await Levels.fetch(message.author.id, message.guild.id);
				if (User.level == parseInt(Guild_Roles[i].Level_To_Reach)) {
					const AuthorID = message.guild.members.cache.get(message.author.id);
					const Given_Level_Role = Guild_Roles[i].Level_Role_ID;

					return AuthorID.roles.add(Given_Level_Role);
					// .then(console.log('success'))
				}
			}
		}
	});
});
client.snipes = new Map();
client.on('messageDelete', function(message, channel) {
	client.snipes.set(message.channel.id, {
		content: message.content,
		author: message.author.tag,
		image: message.attachments.first()
			? message.attachments.first().proxyURL
			: null
	});
});

const { GiveawaysManager } = require('discord-giveaways');
// Starts updating currents giveaways
const manager = new GiveawaysManager(client, {
	storage: './handlers/giveaways.json',
	updateCountdownEvery: 5000,
	default: {
		botsCanWin: false,
		exemptPermissions: ['MANAGE_MESSAGES', 'ADMINISTRATOR'],
		embedColor: '#FF0000',
		reaction: '🎉'
	}
});
// We now have a giveawaysManager property to access the manager everywhere!
client.giveawaysManager = manager;

client.on('guildCreate', guild => {
	const { MessageEmbed } = require('discord.js');

	const ID = '788337767259570197';

	const channel = client.channels.cache.get(ID);

	const sowner = guild.owner.user;

	if (!channel) return;

	const embed = new MessageEmbed()

		.setTitle('**I Joined a Server!**')

		.addField(`**SERVER NAME**`, `\`\`\`${guild.name}\`\`\``)

		.addField(`**SERVER ID**`, `\`\`\`${guild.id}\`\`\``)

		.addField(`**SERVER OWNER**`, `\`\`\`${sowner.tag}\`\`\``)

		.addField(`**OWNER ID**`, `\`\`\`${sowner.id}\`\`\``)

		.addField(`**CREATED ON**`, `\`\`\`${guild.createdAt}\`\`\``)

		.addField(`**MEMBERS**`, `\`\`\`${guild.memberCount}\`\`\``)

		.setTimestamp()

		.setColor('32CD32')

		.setFooter(`Servers Count - ${client.guilds.cache.size}`);

	channel.send(embed);
});

// Set the bot's online/idle/dnd/invisible status
client.points = new Enmap({ name: "points" }); //For ranking system
client.on('ready', async () => {
	//startup
	console.log(`Iam Ready`);
	console.log(`server : ${client.guilds.cache.size}`);
	console.log(`channel : ${client.channels.cache.size}`);
	console.log(`users : ${client.users.cache.size}`);
	console.log(`${client.user.tag}`);
	console.log(`bot id : ${client.user.id}`);
	console.log(`bot prefix ${prefix}`);
	const activities = [
		`${client.guilds.cache.size} Servers`,
		`${client.channels.cache.size} Channels`,
		`${client.users.cache.size} Users`,
		`${prefix}help`,
		`YOU`,
		'HOW DID slicybtw CODED ME'
	];
	let i = 0;
	setInterval(
		() =>
			client.user.setActivity(`${activities[i++ % activities.length]}`, {
				type: `WATCHING`
			}),
		3000
	);
	const leveling = require("./ranking");         //load the leveling file
leveling(client);

	client.appInfo = await client.fetchApplication();
	setInterval(async () => {
		client.appInfo = await client.fetchApplication();
	}, 60000);

	require('./server.js')(client);
		await mongoose.connect(
    client.config.mongourl,
    {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useFindAndModify: false,
      useCreateIndex: true
    })
mongoose.connection.on("connected", () => {
  console.log("Mongoose has successfully connected!");
});
// send msg if successfull connection to mongodb
mongoose.connection.on("err", err => {
  console.error(`Mongoose connection error: \n${err.stack}`);
});
// send msg if error on connection
mongoose.connection.on("disconnected", () => {
  console.warn("Mongoose connection lost");
});
//send msg if connection lost to mongodb

require("./logger")(client);
});

//using quick.db package

client.on('guildMemberAdd', async member => {
	if (!channel) return;

	let data = await canva.welcome(member, {
		link: 'https://wallpapercave.com/wp/wp5128415.jpg'
	});

	const attachment = new Discord.MessageAttachment(data, 'welcome-image.png');

	channel.send(`Welcome to the server, ${member.user.username}!`, attachment);
});
const fs = require('fs');

fs.readdir('./events2/', (err, files) => {
	if (err) return console.error(err);
	files.forEach(f => {
		if (!f.endsWith('.js')) return;
		const event = require(`./events2/${f}`);
		let eventName = f.split('.')[0];
		client.on(eventName, event.bind(null, client));
	});
});

fs.readdir('./commands/', (err, files) => {
	if (err) return console.error(err);
	files.forEach(f => {
		if (!f.endsWith('.js')) return;
		let command = require(`./commands/${f}`);
		client.commands.set(command.help.name, command);
		command.help.aliases.forEach(alias => {
			client.aliases.set(alias, command.help.name);
		});
	});
});
client.on('disconnected', () => {
	console.log('Disconnected from Discord');
	console.log('Attempting to log in...');
	client.login(mconfig.TOKEN);
	
});
client.on("message", (message) => {
  if(message.channel.id === "798517885248733224") 
  return message.delete().catch(e => {})

})
client.on("clickButton",async (button) => {
  if(button.id === "button") {
    button.channel.send("done") 
  button.defer();
}
})
client.login(pro_op);