module.exports = (client) => {
    console.log("ready");
};