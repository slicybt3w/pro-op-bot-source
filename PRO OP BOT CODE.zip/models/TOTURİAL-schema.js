const mongoose = require("mongoose")

const reqString = {
type: String,
required: true
}


const Schema = new mongoose.Schema ({
  

guildId: reqString,
userId: reqString
})

module.exports = mongoose.model("name", schema)
//const db = reauire("../models/filename")