const mongoose = require("mongoose")

const Schema = new mongoose.Schema ({
  

guildId: String,
userId: String,
content: Array
})

module.exports = mongoose.model("member warns", Schema, "users warns")
//const db = reauire("../../models/filename")