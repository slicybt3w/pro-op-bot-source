module.exports = {
    name : 'help-among',
    category: "amongus",
    run : async(client, message, args) => {
        message.channel.send('Click here for more information on how to use the bot -> https://github.com/reconlx/amongus-discord-bot/blob/main/README.md#-commands')
    }
}