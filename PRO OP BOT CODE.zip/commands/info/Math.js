//CALCULATE COMMAND
const math = require('mathjs');
const discord = require('discord.js');
module.exports = {
    name: "calculate",
    category: "info",
    async run (client, message, args){
        if(!args[0]) return message.channel.send('Please provide a math question.');

        let resp;

        try {
            resp = math.evaluate(args.join(" "))
        } catch (e) {
            return message.channel.send('ERROR: Invalid question.')
        }
        const mess = await message.channel.send("Calculating...")
      setTimeout(() => {
          const embed = new discord.MessageEmbed()
        .setColor('GREEN')
        .setTitle('Your solved math question ->')
        .addField('❓Question', `\`\`\`php\n${args.join(' ')}\`\`\``)
        .addField('✅Answer', `\`\`\`php\n${resp}\`\`\``)

        message.channel.send(embed);
      mess.delete()
      }, 900)

    }
}
