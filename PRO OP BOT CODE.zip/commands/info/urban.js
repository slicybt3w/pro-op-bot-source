const discord = require('discord.js')
const { MessageEmbed } = require('discord.js')
const fetch = require('node-fetch')
const querystring = require('querystring')

module.exports = {
  name: "urban",
  category: "info",
  aliases: [""],
  description: "<prefix>urban <word>",
  run: async (client, message, args) => {

      const searchString = querystring.stringify({ term: args.slice(0).join(" ") });

        if (!args.slice(0).join(" ")) return message.channel.send(new MessageEmbed()
            .setColor("BLUE")
            .setDescription(`specify something you want to search the urban dictionary!`)
        )

        const { list } = await fetch(`https://api.urbandictionary.com/v0/define?${searchString}`).then(response => response.json())

        try {
            const [answer] = list

            const trim = (str, max) => ((str.length > max) ? `${str.slice(0, max - 3)}...` : str)

            const embed = new discord.MessageEmbed()
                .setColor("BLUE")
                .setTitle(answer.word)
                .setURL(answer.permalink)
                .addFields(
                    { name: 'Defintion', value: trim(answer.definition, 1024) },
                    { name: 'Example', value: trim(answer.example, 1024) },
                    { name: 'Rating', value: `${answer.thumbs_up} 👍. ${answer.thumbs_down} 👎.` },
                )
                message.react("👍")
                message.react("👎")
            message.channel.send(embed)
        } catch (error) {
            console.log(error)
            return message.channel.send(new discord.MessageEmbed()
                .setColor("BLUE")
                .setDescription(`NOt found result for **${args.slice(1).join(" ")}**`)
            )
        }
    }        
};
