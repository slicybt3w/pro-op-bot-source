module.exports = {
  name: "translate-auto",
  category: "Auto-transletor"
}