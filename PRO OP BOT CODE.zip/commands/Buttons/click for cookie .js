const {Client, Message, MessageEmbed} = require("discord.js")
const { MessageButton } = require('discord-buttons')

module.exports = {
  name: "cookiebutton",
  category: "Buttons",
  /**
   * @param {Message} message
   * @param {Client} client
   * @param {String[]} args
*/
run: async(client, message, args) => {
  
  let button = new MessageButton()
    .setStyle('gray')
    .setLabel('My first button!')
   .setURL(`https://youtube.com/channel/UCqwE6vaLW1eVX6L3msbvTzw`)
    .setID('button');
    message.channel.send("hey click me", button)
}
}