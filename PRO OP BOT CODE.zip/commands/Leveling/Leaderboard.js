module.exports = {
  name: "leaderboard",
  category: "Leveling"
}