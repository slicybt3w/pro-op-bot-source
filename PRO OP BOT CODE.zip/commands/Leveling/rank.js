module.exports = {
  name: "rank",
  category: "Leveling"
}