const Discord = require("discord.js")
const db = require("quick.db")

module.exports = {
  name: "set-welcome",
  category: "welcomer"
}