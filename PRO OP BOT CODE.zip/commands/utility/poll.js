const Discord = require('discord.js');
const { MessageEmbed } = require('discord.js');

module.exports = {
	name: 'poll',
	description: 'Make poll',
	aliases: [],
	category: "utility",
	cooldown: 3,
	run: async (client, message, args, reaction) => {
		if (!message.member.hasPermission('ADMINSTRATION'))
			return message.channel.send('you need Administrator role');
		if (!args[0]) return message.channel.send('send a message');
		const { guild } = message;
		const { name } = guild;
		const icon = guild.iconURL();
		const embed = new MessageEmbed()
			.setTitle(name)
			.setDescription(args.join(' '))
			.setColor('GOLD')
			.setThumbnail(icon)
			.setTimestamp();
		message.delete();
		message.channel.send(embed).then(msg => {
			msg.react('✔️');
			msg.react('✖️');
			msg.react('🤔');
		});
	}
};
