const discord = require("discord.js")

module.exports = {
  name: "ban",
  category: "moderation",
  run: async(client, message, args) => {
    if(!message.member.hasPermission("BAN_MEMBERS")) return message.channel.send("u dont have perms to do that")
    const member = message.mentions.members.first()
    if(!member) return message.channel.send("mention someone to ban")
    let reason = args.slice(0).join(" ")
        message.channel.send(`banned ${member.user.tag} from ${message.guild.name}`)
    await member.ban({reason})
    await member.send(`u have been banned from ${message.guild.name}`)
  }
}