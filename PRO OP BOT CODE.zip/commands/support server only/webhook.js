const { WebhookClient, MessageEmbed } = require('discord.js')

module.exports = {
    name : 'webhook',
    category : 'support server',
    run : async(client, message, args) => {
      
    const wc = new WebhookClient['844680164013244426', 'zACeDrT9RDEM54Z0woGefYvdTvQSWO-lfiBamkiEFI_j8q4DjL0cccl5iiRfJbOzXdlU'];
        const embed = new MessageEmbed()
            .setTitle("this is an embed").setColor('GREEN').setTimestamp().setDescription(args.join(" "))
    wc.send({
        username : message.author.tag,
        avatarURL : message.author.displayAvatarURL({ dynamic : true }),
        embeds : [embed]
    })
    }
}