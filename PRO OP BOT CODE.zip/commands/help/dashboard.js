const discord = require("discord.js")

module.exports = {
  name: "dashboard",
  desicription: "use my dashboard and i will get nothing :D",
  category: "help",
  run: async(client, message, args) => {


  let embed = new discord.MessageEmbed()
      .setTitle("bot dashboard")
        .addField("website", `[Click me](https://pro-op-dashboard.oday549night.repl.co/)`,true)
        message.channel.send(embed)
}
,}