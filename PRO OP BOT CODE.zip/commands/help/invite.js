const discord = require("discord.js");

module.exports = {
  name: "invite",
  category: "info",
  description: "Invite ServerManager",
  run: async (client, message, args) => {
    
    let embed = new discord.MessageEmbed()
    .setTitle(`Links`)
    .addField("invite [click me]",  `[link](https://discord.com/oauth2/authorize?client_id=808273298235457607&scope=bot&permissions=2147483647.)`)
    .setColor("RANDOM")
    .setTimestamp(message.timestamp = Date.now())
    
    message.channel .send(embed)
    
  
  }
}