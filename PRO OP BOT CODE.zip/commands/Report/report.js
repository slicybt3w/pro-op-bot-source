const {Client, Message, MessageEmbed} = require("discord.js")

module.exports = {
  name: "report",
  category: "Report/bug",
  /**
* @param {Client} client
* @param {Message} message
* @param {String[]} args
*/
run: async(client, message, args) => {
  const owner = client.user.cache.get("788337767259570197")
  
  const query = args.join(" ")

  if(!query) return message.channel.send("input a query to send the bug")
  const report = new MessageEmbed()
  .setTitle("New Bug!")
  .addField("author", message.author.toString(), true)
  .addField("author id", message.author.id, true)
.addField("guild", message.guild.name, true)
.addField("bug", query)
.setThumnibal(message.author.displayAvatarURL({dynamic: true}))
.setTimeStamp()
owner.send(report)
  
}
}