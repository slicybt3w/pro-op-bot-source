const discord = require("discord.js")

module.exports = {
  name: "votebot",
  desicription: "vote for a bot",
  category: "Other",
  run: async(client, message, args) => {


  let embed = new discord.MessageEmbed()
      .setTitle("vote for the bot")
        .addField("top.gg", `[Click me](https://top.gg/bot/808273298235457607)`, true)
        .addField("discord.ly", "[Click Me](https://discord.ly/slicy-btw-o)", true)
      .setColor("RANDOM")
      message.channel.send(embed)
  }
}
