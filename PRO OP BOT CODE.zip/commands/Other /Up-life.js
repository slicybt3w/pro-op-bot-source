const {Client, Message, MessageEmbed} = require("discord.js")

module.exports = {
  name: "u+help",
  category: "Other"
}